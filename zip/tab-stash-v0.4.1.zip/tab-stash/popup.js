async function listGroups(){
  const { groups = [] } = await chrome.storage.local.get('groups');
  const el = document.getElementById('groups');
  if (!groups.length){ el.innerHTML = '<small>还没有收起过标签 ✨</small>'; return; }
  el.innerHTML = groups.slice(-5).reverse().map(g => `
    <b>${g.name} <small>(${g.tabs.length})</small></b>
    ${g.tabs.slice(0,3).map(t=>`· ${t.title?t.title.slice(0,40):t.url}`).join('<br/>')}
  `).join('<hr style="border:none;border-top:1px dashed #ccc;margin:6px 0"/>');
}

document.getElementById('stash').addEventListener('click', async ()=>{
  const tabs = await chrome.tabs.query({currentWindow:true});
  const tabData = tabs.filter(t=>!t.pinned).map(t=>({title:t.title,url:t.url}));
  if(!tabData.length) return;
  const { groups = [] } = await chrome.storage.local.get('groups');
  groups.push({name:'手动收起 · '+new Date().toLocaleString(), tabs:tabData, ts:Date.now()});
  await chrome.storage.local.set({groups});
  document.getElementById('status').textContent = '已收起 ' + tabData.length + ' 个标签';
  for (const t of tabs) if (!t.pinned) chrome.tabs.remove(t.id);
  listGroups();
});

document.getElementById('ai-stash').addEventListener('click', async ()=>{
  const { llmKey } = await chrome.storage.local.get('llmKey');
  if(!llmKey){ document.getElementById('status').textContent = '先去设置里填 LLM key 哈'; return; }
  document.getElementById('status').textContent = 'AI 分组功能演示版,真实分组逻辑请补全 popup.js 里 callLLM()';
});

document.getElementById('opt').addEventListener('click', e=>{e.preventDefault(); chrome.runtime.openOptionsPage();});

listGroups();
