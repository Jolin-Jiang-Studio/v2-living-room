const todayKey = () => 'cups-' + new Date().toISOString().slice(0,10);

async function refresh(){
  const k = todayKey();
  const data = await chrome.storage.local.get([k, 'minutes']);
  document.getElementById('stat').textContent = '今天 ' + (data[k]||0) + ' 杯';
  if(data.minutes) document.getElementById('mins').value = data.minutes;
}

document.getElementById('drink').addEventListener('click', async ()=>{
  const k = todayKey();
  const data = await chrome.storage.local.get(k);
  const cups = (data[k]||0) + 1;
  await chrome.storage.local.set({[k]: cups});
  refresh();
});

document.getElementById('save').addEventListener('click', async ()=>{
  const m = Math.max(5, Math.min(240, parseInt(document.getElementById('mins').value,10)||45));
  await chrome.storage.local.set({minutes: m});
  chrome.alarms.clear('hydrate', ()=>{
    chrome.alarms.create('hydrate', {periodInMinutes: m});
  });
  document.getElementById('save').textContent = '已保存 ✓';
  setTimeout(()=>document.getElementById('save').textContent='保存', 1500);
});

refresh();
