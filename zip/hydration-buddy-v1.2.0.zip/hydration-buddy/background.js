chrome.runtime.onInstalled.addListener(async () => {
  const { minutes } = await chrome.storage.local.get('minutes');
  const m = minutes || 45;
  chrome.alarms.create('hydrate', { periodInMinutes: m });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== 'hydrate') return;
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icon.png',
    title: '💧 该喝水啦',
    message: '小姜提醒你:站起来喝一杯水,顺便活动活动脖子。',
    priority: 1
  });
});
